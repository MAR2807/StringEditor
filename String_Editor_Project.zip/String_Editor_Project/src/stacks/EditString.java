package stacks;

import java.util.Scanner;
import java.util.Stack;

public class EditString {

	public static void main(String[] args) {
		ArrayBoundedStack<String> edits = new ArrayBoundedStack<String>();
	    Stack<Character> letterStack1 = new Stack<>();
	    Stack<Character> letterStack2 = new Stack<>();
		
		String b;
		Scanner sc = new Scanner(System.in);
		Scanner sc2 = new Scanner(System.in);
		
		System.out.println("Enter a string");
		String a = sc.nextLine();
		char letter2 = 0;
		char letter1 = 0;
		
	int check=0;
	
	while(check==0) {
		
		System.out.println("Enter edit");
		 b = sc2.nextLine().toLowerCase();
		
		if(!b.equals("x")&&!b.equals("c") &&!b.equals("z")) {
			edits.push(b);
			System.out.println(edits);
		}
		else if(b.equals("c")) {
			edits.push(b);
		    System.out.print("Enter two letters: ");
		    Scanner sc3 = new Scanner(System.in);
		    letter1 = sc3.next().charAt(0);
		    letter2 = sc3.next().charAt(0);
		    letterStack1.push(letter1);
		    letterStack2.push(letter2);
		}
		else if(b.equals("z")&& edits.top().equals("c")) {
				edits.pop();
				letterStack1.pop();
				letterStack2.pop();
		}
		else if(b.equals("z") && !edits.top().equals("c")) {
			edits.pop();
		}
	
		else if(b.equals("x")) {
			
			System.out.println("");
			String bb = sc.nextLine().toLowerCase();
			if(!bb.equals("z")) {
				System.out.print(EditString2(a,edits,letterStack1,letterStack2));
			}
			else {
				while(bb.equals("z")&& !edits.isEmpty()) {
					if(edits.top().equals("c")) {
						edits.pop();
						letterStack1.pop();
						letterStack2.pop();
					}
					else {
						edits.pop();
					}

					System.out.println("");
					bb = sc.nextLine();
					
					if(!bb.equals("z")||edits.isEmpty()) {
						System.out.print(EditString2(a,edits,letterStack1,letterStack2));
					}
				}
			}
			
			//
			break;
			
		}
	}

	}

	public static String EditString2(String a, ArrayBoundedStack<String> edits, Stack<Character> letterStack1, Stack<Character> letterStack2) {
		
		if(edits.isEmpty()) {
			return a;
		}
		else {
			String g = edits.top();
		
			if(g.equals("u")) {
				a = a.toUpperCase();
			}
			else if(g.equals("l")) {
				a = a.toLowerCase();
			}
			else if(g.equals("r")) {
				a = reverseString(a);
			}
			else if(g.equals("c")) {

			    char[] charArray = a.toCharArray();
			    char letter1Top=letterStack1.pop();
			    char letter2Top=letterStack2.pop();
			    for (int i = 0; i < charArray.length; i++) {
			        if (charArray[i] == letter1Top) {
			            charArray[i] = letter2Top;
			        }
			       
			    }
			        a = new String(charArray);
			       // System.out.println("After switching places: " + results);
			    } 
			}
			edits.pop();
			return EditString2(a,edits, letterStack1, letterStack2);
			
			
		}

public static String reverseString(String s) {
	if( s.equals("")) {
		return "";
	}
	else {
		return "" + s.charAt(s.length()-1)+ reverseString(s.substring(0,s.length()-1));
	}
}
}
